#include "ros/ros.h"
#include "std_msgs/Float64.h"

double input;

void turtleCallback(const std_msgs::Float64::ConstPtr& msg)
{
	input = msg->data;
}


int main (int argc, char **argv)
{
	// Initialize the node, setup the NodeHandle for handling the communication with the ROS
	//system
	ros::init(argc, argv, "joint_listener");
	ros::NodeHandle nh;
	ros::Publisher pub = nh.advertise<std_msgs::Float64>("/end/command",100);
	// Define the subscriber to turtle's position
	ros::Subscriber sub = nh.subscribe("joint6/command", 100,turtleCallback);	
	double max = 0;	
	ros::Rate loop_rate(10);

	while(ros::ok()){
		std_msgs::Float64 pubMsg;
		if( input > max ){
			pubMsg.data = input; 
			pub.publish(pubMsg);
			max = input;	
		}

		ros::spinOnce();
		loop_rate.sleep();
	}
	
	return 0;
}
