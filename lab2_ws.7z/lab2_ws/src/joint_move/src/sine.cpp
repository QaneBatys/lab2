#include "ros/ros.h"
#include "std_msgs/Float64.h"

double input;


int main (int argc, char **argv)
{
	// Initialize the node, setup the NodeHandle for handling the communication with the ROS
	//system
	ros::init(argc, argv, "joint_listener");
	ros::NodeHandle nh;
	ros::NodeHandle nh1;
	ros::NodeHandle nh2;
	ros::NodeHandle nh3;
	ros::NodeHandle nh4;	

	ros::Publisher pub = nh.advertise<std_msgs::Float64>("/motortom2m/command",100);
	ros::Publisher pub1 = nh1.advertise<std_msgs::Float64>("/joint2/command",100);
	ros::Publisher pub2 = nh2.advertise<std_msgs::Float64>("/joint4/command",100);
	ros::Publisher pub3 = nh3.advertise<std_msgs::Float64>("/joint6/command",100);	
	ros::Publisher pub4 = nh4.advertise<std_msgs::Float64>("/end/command",100);
	// Define the subscriber to turtle's position	
	ros::Rate loop_rate(25);
	double t=0.0;
	double r=3.14;
	double y;
	double y1;

	std_msgs::Float64 msg;

	while(ros::ok()){
		t+=0.1;
		r+=0.1;
		
		y = 0.7*sin(t);
		y1 = 0.7*sin(r);
		msg.data = y /2;		
		pub.publish(msg);
		msg.data = y1;
		pub1.publish(msg);
		msg.data = y;
		pub2.publish(msg);
		msg.data = y1;
		pub3.publish(msg);
		msg.data = y;
		pub4.publish(msg);
		

		ros::spinOnce();
		loop_rate.sleep();
	}
	
	return 0;
}
